x = parse( Int32, ARGS[1] )
y = parse( Int32, ARGS[2] )
summ = x + y
println("The sum of the two numbers is ", summ)