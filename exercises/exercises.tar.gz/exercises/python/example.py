# This program will add two numbers that are provided by the user in this file
     
# Get the numbers
a = 237
b = 523789
     
# Add the two numbers together
sum = a + b
     
# Output the sum
print("The sum of {0} and {1} is {2}".format(a, b, sum))
