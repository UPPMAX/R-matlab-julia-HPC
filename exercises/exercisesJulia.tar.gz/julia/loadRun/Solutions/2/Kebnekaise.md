                $ ml purge  > /dev/null 2>&1       # recommended purge
                $ ml Julia/1.8.5-linux-x86_64      # Julia module
                        
                $ julia serial-sum.jl Arg1 Arg2    # run the serial script
