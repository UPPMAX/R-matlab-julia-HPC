
print("Hello World")

argv <- commandArgs(TRUE)
cat("value of argument=", argv[1])
